unless User.all.count.positive?
  User.create!(
      email: 'example@mail.com' ,
      password: '123123123' ,
      password_confirmation: '123123123'
  )
end
