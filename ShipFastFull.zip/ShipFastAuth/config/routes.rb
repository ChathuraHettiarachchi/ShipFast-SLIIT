Rails.application.routes.draw do
  namespace :api do
    namespace :v1 do
      post 'authenticate', to: 'authentication#authenticate'

      get 'orders', to: 'order#index'
      post 'order', to: 'order#create'
      get 'order/:id', to: 'order#order'

      get 'delivery/:id', to: 'delivery#status'
      post 'delivery/:id', to: 'delivery#cancel'
    end
  end
end
